﻿Pasta for Prism Launcher

Import this ZIP through Add Instance -> Import.
Packwiz will install the client pack on first launch and update it before every later launch.
Keep an Internet connection available while updating.
